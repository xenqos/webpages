# Poker Outs

Delployed [HERE](https://poker-outs.netlify.app/)

This only-front-end project calculates the odds of hitting poker outs when you input your cards


