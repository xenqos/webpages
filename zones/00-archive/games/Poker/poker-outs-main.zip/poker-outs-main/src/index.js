import './style.scss';
import ReactDOM from 'react-dom';
import React from 'react';
import App from './app';

// Note: My app is in app.js

ReactDOM.render(<App />, document.getElementById('main'));
